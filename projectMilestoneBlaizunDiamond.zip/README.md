# GraphicsFinalProject
make using make ex26. I will change this when i turn in the final.
 So far I have the grass blade instancing and rotations mostly working. Jury is still out whether or not the normals are being changed correctly. Still have a lot to do to get the grass curved and to add the wind system. Also need to adjust the lighting and add a moon. After that I will be tackling the gravestones and fences and the like. Hopefully. 
 
 I know this doesnt look like a lot, but it has taken a substantial amount of work and learning to get to this point. 